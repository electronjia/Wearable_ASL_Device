from math import exp
from random import seed
from random import random
import sys
import random
import ast
import serial
import datetime
import time
import os
import subprocess
import I2C_LCD_driver

old_time = 0.0
too_soon = 0.0
force_interval = 5.0 #screen needs about 2.01 seconds to display and clear

def play_my_sound(filename):
    global old_time
    global too_soon
    elapsed_time = time.time() - old_time + too_soon
    old_time = time.time()
    if(elapsed_time > force_interval):
        too_soon = 0.0
        os.system(filename)
        #os.popen(filename) #10/19
    else:
       print("too soon!")
       too_soon = 6.0 

def load_file(filename):
    with open(filename, 'r') as f:
        dataset = [[int(num) for num in line.split()] for line in f]
    return dataset

def normalize_data(row):
    for i in range(len(row)):
        row[i] = row[i]/float(1023)
    return row

def normalize_dataset_with_class(dataset):
    for row in dataset:
        for i in range(len(row)-1):
            row[i] = row[i]/float(1023)
        row[-1] = int(row[-1])
    return dataset

def normalize_dataset_no_class(dataset):
    for row in dataset:
        for i in range(len(row)):
            row[i] = row[i]/float(1023)
    return dataset

def alpha(weights, inputs):
    alpha = weights[-1]
    for i in range(len(weights)-1):
        alpha += weights[i] * inputs[i]
    return alpha

def activation_function(activation):
    return round(1.0 / (1.0 + exp(-activation)),4)

def forward_propagate(network,row):
    inputs = row
    for layer in network:
        new_inputs = []
        for neuron in layer:
            alpha_value = alpha(neuron['weights'],inputs)
            neuron['output'] = activation_function(alpha_value)
            new_inputs.append(neuron['output'])
        inputs = new_inputs
    return inputs
    
# def forward_propagate(network, row):
    # inputs = row
    # for layer in network:
        # new_inputs = []
        # for neuron in layer:
            # alpha_value = alpha(neuron['weights'], inputs)
            # neuron['output'] = activation_function(alpha_value)
            # new_inputs.append(neuron['output'])
        # inputs = new_inputs
    # return inputs

def predict_sign(network, test_data):
    outputs = forward_propagate(network,test_data)
    max_output = max(outputs)
    predict = outputs.index(max_output)
    return predict


def fun(network,gesture):
    serial_port='/dev/ttyACM0'
    acc = []
    ser = serial.Serial(serial_port,115200)
    ser.reset_input_buffer()
    j = 0
    while True:
        try:
            for i in range(0,5):
                row = ser.readline().decode('utf-8')
                temp = [float(num) for num in row.split()]
                dataset = normalize_data(temp)
                dataset.append(j)
                sign = predict_sign(network,dataset)
                print(gesture[sign])
                mylcd.lcd_display_string(gesture[sign], 1)
                play_my_sound(sounds[sign])
                time.sleep(2), mylcd.lcd_clear()
                #play_my_sound(omxlcd[sign]) #10/19
                sys.stdout.flush()
        except KeyboardInterrupt:
            file.close()
            break
    ser.close()
    return acc

mylcd = I2C_LCD_driver.lcd()
print('Start Testing')
mylcd.lcd_display_string("Please sign", 1)
mylcd.lcd_display_string("a gesture.", 2)
os.system("omxplayer -o local '/home/pi/code/audio/gesture.mp3'")
time.sleep(2), mylcd.lcd_clear()
file = open("/home/pi/code/network.txt","r")
contents = file.read()
network = ast.literal_eval(contents)
file.close()
accuracy = []
gesture = ["A","T","U"]
#OY place a list of audio files here -- make sure these fields exist
sounds = ["omxplayer -o local '/home/pi/code/audio/A.mp3'","omxplayer -o local '/home/pi/code/audio/T.mp3'","omxplayer -o local '/home/pi/code/audio/U.mp3'"]
#screen= ["python3 /home/pi/code/text/A_text.py","python3 /home/pi/code/text/T_text.py","python3 /home/pi/code/U_text.py"]
#omxlcd=['sh /home/pi/code/bash/A_bash.sh','sh /home/pi/code/bash/T_bash.sh','sh /home/pi/code/bash/U_bash.sh']
#gesture = ["L","O","X"]
#sounds = ["omxplayer -o local '/home/pi/code/audio/L.mp3'","omxplayer -o local '/home/pi/code/audio/O.mp3'","omxplayer -o local '/home/pi/code/audio/X.mp3'"]


if len(sys.argv) >= 2:
    data = load_file(sys.argv[1])
    if (len(sys.argv) == 3):
        if (sys.argv[2] == "trueclass"):
            response = "y"
        elif (sys.argv[2] == "notrueclass"):
            response = "n"
    else:
        response = raw_input('Does the input file include true class? ')
    if response == "n":
        data = normalize_dataset_no_class(data)
        for row in data:
            sign = predict_sign(network, row)
            print(gesture[sign]) #OY possibly place audio here
            #os.system(screen[sign]) #10/7
            mylcd.lcd_display_string(gesture[sign], 1)
            play_my_sound(sounds[sign])
            time.sleep(2), mylcd.lcd_clear()
            #play_my_sound(omxlcd[sign]) #10/19
    elif response == "y":
        data = normalize_dataset_with_class(data)
        print("\n\nActual           |   Predicted")
        print("----------------------------------")
        for row in data:
            sign = predict_sign(network, row)
            print(gesture[row[-1]]+"    |   "+gesture[sign])
            if row[-1] == sign:
                accuracy.append(1)
            else:
                accuracy.append(0)
        prediction_acc = round((sum(accuracy)/float(len(accuracy)))*100,2)
        print("\nPrediction accuracy is "+str(prediction_acc)+"%")
else:
    accuracy = fun(network,gesture)
print('\nEnd Testing')
mylcd.lcd_display_string("Signing", 1)
mylcd.lcd_display_string("Completed", 2)
os.system("omxplayer -o local '/home/pi/code/audio/complete.mp3'")
time.sleep(2), mylcd.lcd_clear()